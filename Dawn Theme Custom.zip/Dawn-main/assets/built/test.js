$(document).ready(function () {
    // Function to load more posts
    function loadMorePosts(tagSlug, skip, limit) {
        $.get(`/ghost/api/v3/content/tags/${tagSlug}/posts/?key=YOUR_CONTENT_API_KEY&limit=${limit}&page=${skip}`)
            .done(function (data) {
                var $postList = $('.post-list');
                data.posts.forEach(function (post) {
                    // Create and append HTML for each post here
                    var postHtml = `
                        <article class="feed ${post.visibility} ${post.post_class}">
                            <!-- Include post content here -->
                        </article>
                    `;
                    $postList.append(postHtml);
                });

                // Check if there are more posts to load
                if (data.meta.pagination.next) {
                    $('.gh-loadmore2').show(); // Show the "Load more" button
                } else {
                    $('.gh-loadmore2').hide(); // Hide the button if no more posts
                }
            })
            .fail(function (error) {
                console.error('Error loading more posts:', error);
            });
    }

    // Initialize variables
    var tagSlug = 'your-tag-slug'; // Replace with the desired tag slug
    var skip = 2; // Change this to match your desired page number
    var limit = 5; // Number of posts to load per page

    // Load more posts when the button is clicked
    $('.gh-loadmore2').on('click', function () {
        loadMorePosts(tagSlug, skip, limit);
        skip++; // Increment the page number
    });
});
